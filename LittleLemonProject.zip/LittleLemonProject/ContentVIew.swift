//
//  ContentVIew.swift
//  LittleLemonProject
//
//  Created by Señor Haslam on 9/4/23.
//

import SwiftUI

struct ContentVIew: View {
    @State private var name = ""
    @State private var partySize = 1
    @State private var reservationDate = Date()
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Reservation Details")) {
                    TextField("Name", text: $name)
                    Stepper("Party Size: \(partySize)", value: $partySize, in: 1...20)
                    DatePicker("Date", selection: $reservationDate, displayedComponents: .date)
                }
                Section {
                    Button("Reserve a Table") {
                    }
                }
            }
        }
    }
}
    struct ContentVIew_Previews: PreviewProvider {
        static var previews: some View {
            ContentVIew()
        }
    }

