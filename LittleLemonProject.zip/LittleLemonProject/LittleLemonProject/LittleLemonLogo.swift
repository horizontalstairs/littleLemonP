//
//  LittleLemonLogo.swift
//  LittleLemonProject
//
//  Created by Señor Haslam on 9/4/23.
//


import SwiftUI

struct LittleLemonLogo: View {
    // Added logo from assets
    var body: some View {
        Image("littleLemon")
    }
}

struct LittleLemonLogo_Previews: PreviewProvider {
    static var previews: some View {
        LittleLemonLogo()
    }
}
