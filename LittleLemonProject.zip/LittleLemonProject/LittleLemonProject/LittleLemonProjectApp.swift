//
//  LittleLemonProjectApp.swift
//  LittleLemonProject
//
//  Created by Señor Haslam on 9/4/23.
//

import SwiftUI

@main
struct LittleLemonProjectApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
